using System.Data;

namespace ShahBuyerAuthApi.Data.Models
{
    public class Review
    {
        public string Id { get; set; } = System.Guid.NewGuid().ToString();
        public string BuyerProfileId { get; set; } = null!;
        public BuyerProfile BuyerProfile { get; set; } = null!;
        public string ProductId { get; set; } = null!;
        public Product Product { get; set; } = null!;

        public int Rating { get; set; } // 1..5
        public string Comment { get; set; } = null!;
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
