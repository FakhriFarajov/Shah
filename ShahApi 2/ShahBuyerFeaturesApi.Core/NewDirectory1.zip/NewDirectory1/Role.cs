using System.Collections.Generic;

namespace ShahBuyerAuthApi.Data.Models
{
    public class Role
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string RoleName { get; set; } = null!;

        public string UserId { get; set; }
        public User User { get; set; }
    }
}
